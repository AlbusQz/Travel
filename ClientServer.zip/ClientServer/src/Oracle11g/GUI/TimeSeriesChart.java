package Oracle11g.GUI;

import java.awt.Font;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.time.Day;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;

import Oracle11g.Entity.AbstractAdmin;
import Oracle11g.Entity.History;

public class TimeSeriesChart {
	ChartPanel frame1;
	public TimeSeriesChart() throws Exception{
		XYDataset xydataset = createDataset();
		JFreeChart jfreechart = ChartFactory.createTimeSeriesChart("每日订单数量统计", "日期", "数量",xydataset, true, true, true);
		XYPlot xyplot = (XYPlot) jfreechart.getPlot();
		DateAxis dateaxis = (DateAxis) xyplot.getDomainAxis();
        dateaxis.setDateFormatOverride(new SimpleDateFormat("MM-dd"));
        frame1=new ChartPanel(jfreechart,true);
        dateaxis.setLabelFont(new Font("黑体",Font.BOLD,14));         //水平底部标题
        dateaxis.setTickLabelFont(new Font("宋体",Font.BOLD,12));  //垂直标题
        ValueAxis rangeAxis=xyplot.getRangeAxis();//获取柱状
		rangeAxis.setAutoRange(true);
        rangeAxis.setLabelFont(new Font("黑体",Font.BOLD,15));
        jfreechart.getLegend().setItemFont(new Font("黑体", Font.BOLD, 15));
        jfreechart.getTitle().setFont(new Font("宋体",Font.BOLD,20));//设置标题字体

	} 
	private static XYDataset createDataset() throws Exception{
		TimeSeries timeseries = new TimeSeries("订单数量");
		List<History> list = AbstractAdmin.getAdmin().getHistory("");
		Map<String, Integer> map = new HashMap<>();
		for(History h : list){
			String type = h.getCtime().toString().split(" ")[0];		//type means date
			int value = 1;
			if(map.containsKey(type))
				value = map.get(type) + 1;
			map.put(type, value);
		}
		for(Entry<String, Integer> entry : map.entrySet()){
			String[] key = entry.getKey().split("-");
			timeseries.add(new Day(Integer.parseInt(key[2]), Integer.parseInt(key[1]), Integer.parseInt(key[0])), entry.getValue());
		}
		TimeSeriesCollection timeseriescollection = new TimeSeriesCollection();
		timeseriescollection.addSeries(timeseries);
		return timeseriescollection;
	}
	  public ChartPanel getChartPanel(){
	    	return frame1;
	    }
}
